package college;

import java.util.Scanner;

public class rightmost {
	public static void main (String[] args) {
//		int num=234;
		Scanner sc=new Scanner(System.in);
		int num=sc.nextInt();
		System.out.println(num%10);
		
//				System.out.println(num%100);         for last two digits
	}
}