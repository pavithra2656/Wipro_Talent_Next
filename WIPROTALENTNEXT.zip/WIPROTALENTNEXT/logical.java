package college;

public class logical {
	public static void main(String[] args) {
		int a=5,b=10;
		System.out.println("a>b && a == 5 "+((a>b)&&(a==3)));
		System.out.println("a<b || b == 0 "+((a<b)||(b==1)));
	}
}